# OftaSys

Comandos:
    * make: Compila o projeto
    * make clean: Limpa os diretórios obj e bin
    * ./catarata imagens/Catarata.ppm: Executa o projeto passando como argumento o caminho da imagem.